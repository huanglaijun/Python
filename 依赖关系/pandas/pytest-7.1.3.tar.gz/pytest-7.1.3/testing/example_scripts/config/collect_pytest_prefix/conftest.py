class pytest_something:
    pass
