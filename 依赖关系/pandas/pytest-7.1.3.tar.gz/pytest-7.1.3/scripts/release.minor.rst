pytest-{version}
=======================================

The pytest team is proud to announce the {version} release!

This release contains new features, improvements, and bug fixes,
the full list of changes is available in the changelog:

    https://docs.pytest.org/en/stable/changelog.html

For complete documentation, please visit:

    https://docs.pytest.org/en/stable/

As usual, you can upgrade from PyPI via:

    pip install -U pytest

Thanks to all of the contributors to this release:

{contributors}

Happy testing,
The pytest Development Team
