=================
Development Guide
=================

The contributing guidelines are to be found :ref:`here <contributing>`.
The release procedure for pytest is documented on
`GitHub <https://github.com/pytest-dev/pytest/blob/main/RELEASING.rst>`_.
