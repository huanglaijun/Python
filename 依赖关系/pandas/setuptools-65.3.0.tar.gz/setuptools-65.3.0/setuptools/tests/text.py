class Filenames:
    unicode = 'smörbröd.py'
    latin_1 = unicode.encode('latin-1')
    utf_8 = unicode.encode('utf-8')
