bottleneck.benchmark package
============================

Submodules
----------

bottleneck.benchmark.autotimeit module
--------------------------------------

.. automodule:: bottleneck.benchmark.autotimeit
   :members:
   :undoc-members:
   :show-inheritance:

bottleneck.benchmark.bench module
---------------------------------

.. automodule:: bottleneck.benchmark.bench
   :members:
   :undoc-members:
   :show-inheritance:

bottleneck.benchmark.bench\_detailed module
-------------------------------------------

.. automodule:: bottleneck.benchmark.bench_detailed
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: bottleneck.benchmark
   :members:
   :undoc-members:
   :show-inheritance:
