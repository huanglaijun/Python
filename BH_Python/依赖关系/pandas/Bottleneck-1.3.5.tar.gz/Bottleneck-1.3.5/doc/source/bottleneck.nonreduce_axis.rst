bottleneck.nonreduce_axis module
================================

Module contents
---------------

.. automodule:: bottleneck.nonreduce_axis
   :members:
   :undoc-members:
   :show-inheritance:
