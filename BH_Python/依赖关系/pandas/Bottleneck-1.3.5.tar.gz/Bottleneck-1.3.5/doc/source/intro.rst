.. include:: ../../README.rst
   :start-line: 4
