
Release notes for NumExpr 3.0 series
=====================================

Changes from 3.0.1a4 to 3.0.1a6
-------------------------------

* Python 3.6 is now the minimum requirement in order to support f-strings. 
* Python 3.8 is now supported.
* Allow scalars to be cast to match an array even if it is 'unsafe' by the 
  standard of `np.can_cast`. I.e. for an array `a` with `dtype == np.float32` 
  previously `ne3.evaluate('2*a')` would create an error as 2 defaults to `np.int32`. 
  Now '2' will be seemlessly cast to `np.float32`.
* Fixed a bug whereby scalars where the user could provide an assignment target
  with the wrong dtype and the execution would fail silently. Now raises a 
  `ValueError`.
* Now uploading to PyPi with `twine`.

Changes from 3.0.1a4 to 3.0.1a5
-------------------------------

* Fixed an error when `local_dict` was passed as an input argument to a 
  `NumExpr` initialization.

Changes from 3.0.1 to 3.0.1a4
-----------------------------

* Added integer mod/remainder and integer floor division.
* At the suggestion of Gowtham Sviaraman, added support for integer power.
  As with NumPy, the integer power will overflow. Also added an analog of 
  `numpy.float_power`.
* At the suggestion of Jim Pivarski, added a number of functions to more 
  fully cover the `numpy` namespace, including:
  - `minimum`: maps to minimum values in two arrays, analog to `numpy.minimum`.
     Replaces `fmin`.
  - `maximum`: maps to maximum values in two arrays, analog to `numpy.maximum`.
     Replaces `fmax`.
  - `rad2deg`, `radians`, `deg2rad`, and `degrees`: as their `numpy` equivalents.
  - `factorial`: analog to `scipy.special.factorial` with `exact=False`. Is not 
    rounded to maintain the same behavoir as `scipy`.
  - `heaviside`: heaviside function, analog to `numpy.heaviside`.
  - `logaddexp`: logrithm of the sum of exponents, for comparing very small 
     probabilities.
  - `logaddexp2`: base-2 logrithm of the sum of exponents, for comparing very 
     small probabilities.
  - `sign`: returns -1 for negative numbers, +1 for positive, and 0 for unity, 
     analog to `np.sign`.
  - `tgamma` renamed to `gamma`.
  - `pow` function added in addition to `**` operator.
  - `mod` function added in addition to `%` operator.
* Added complex functions:
  - `angle`: computes the complex phase
  - `crosspower`: computes the cross-power spetrum.

Changes from 3.0.0 to 3.0.1
---------------------------

* **Minimum supported version is now Python 3.4**. 3.3 may work, 2.7 will not.
* Explicit casting operations are now present, including unsafe casts. E.g. 

      a - np.arange(2**12)                  # int-32
      double - ne3.NumExpr('float64(a)')()  # Safe
      trunc - ne3.NumExpr('int8(a)')()      # Unsafe

  For complex numbers, use the `complex`,`real`, and `imag` machinery.
* Complex numbers can be reduced to real or imag as if attributes, e.g.

      imag_num - ne3.NumExpr( '(2.0*np.pi*sin(complex128(a,b))).imag' )()
      
* Transcendental functions (such as `sin`) will now automatically upcast 
  integers to floating-point, mimicing NumPy except for u/int-8 which is upcast
  to float-32 instead of float-16.
* Broadcasting is now calculated internally for allocation of magic output.  
  This is a step on the route to reimplementing reductions.
* Re-use of temporaries is more efficient.
* There is no longer a MAX_THREADS.  All threading resources are now 
  dynamically allocated.  The maximum number of arguments in a function is now 
  set by the NumPy install (default is 32, unless one recompiles with a different 
  macro).
* Temporaries are now pre-allocated in a block (or arena) rather than being 
  individually allocated by the virtual machine at runtime. If the total 
  temporary space is too small it will be `realloc`ed to be the appropriate 
  size.  This space can be managed by `set_tempsize( new_size_per_thread)`. 
  Setting the temporary size to zero will release all temporary memory.  
* Python-side NumExpr and their associated C-extension objects are now 
  pickleable.  As an part of this, constants no longer occupy BLOCKSIZE memory 
  and are instead singleton arrays with a `numpy.nditer` stride of zero.
* Complex division with float-32 is now explicitly a fast but lower precision
  implementation compared to NumPy.
* Benchmark profile points can be set with the macros in `benchmark.hpp`
* Utilities to set and get the number of nthreads have been re-worked to 
  be more robust. An effort was made to turn them into module-level properties
  but was not reliable.

TODO List:
^^^^^^^^^^

* Don't overwrite PyObject_HEAD in pickling
* documentation and tutorial RSTs
  - Probably we will have to tag to get a seperate branch docs?
    http://docs.readthedocs.io/en/latest/versions.html
    
* optimization
  1. BLOCK_SIZE
    - Optimize by dtype.itemsize?
  2. TASKS_PER_THREAD 
    - (optimize to reduce thread barrier encounters?)
    - Largish-values seem to work well for larger arrays
    - Load balance between cores seems to be poor-ish based on early benchmark
      numbers
  3. benchmark keeping the GIL; releasing it doesn't serve much purpose.
  4. Seperate branches for stride-0 operations against scalars.
    - Use a switch-case with a pre-computed mask. A jump table should be 
      branchless?  Maybe I should make some short functions and examine the 
      assembly?
    - Try some of these tricks:
      http://locklessinc.com/articles/vectorize/
      http://llvm.org/docs/Vectorizers.html
      http://gcc.gnu.org/projects/tree-ssa/vectorization.html
    - In-place operations can't be 'restrict' so perhaps I over-optimized 
      temporaries?
  5. Generally MSVC is mediocre at auto-vectorization compared to GCC
    - Can we build with LLVM? Is there a `distutils` extension somewhere?
  6. Try `-ffast-math` for GCC and `/fp:fast` for MSVC.  
     - Might kill NaN and Inf support.
     - Guided optimization via profiling? (`-fprofile-arcs`)



Release notes for Numexpr 2.4 series
====================================

Changes from 2.4.3 to 2.4.4
---------------------------

* Honor OMP_NUM_THREADS as a fallback in case NUMEXPR_NUM_THREADS is not
  set. Fixes #161.

Changes from 2.4.2 to 2.4.3
---------------------------

* Comparisons with empty strings work correctly now.  Fixes #121 and
  PyTables #184.

Changes from 2.4.1 to 2.4.2
---------------------------

* Improved setup.py so that pip can query the name and version without
  actually doing the installation.  Thanks to Joris Borgdorff.

Changes from 2.4 to 2.4.1
-------------------------

* Added more configuration examples for compiling with MKL/VML
  support.  Thanks to Davide Del Vento.

* Symbol MKL_VML changed into MKL_DOMAIN_VML because the former is
  deprecated in newer MKL.  Thanks to Nick Papior Andersen.

* Better determination of methods in `cpuinfo` module.  Thanks to Marc
  Jofre.

* Improved NumPy version determination (handy for 1.10.0).  Thanks
  to Åsmund Hjulstad.

* Benchmarks run now with both Python 2 and Python 3.  Thanks to Zoran
  Plesivčak.

Changes from 2.3.1 to 2.4
-------------------------

* A new `contains()` function has been added for detecting substrings
  in strings.  Only plain strings (bytes) are supported for now.  See
  PR #135 and ticket #142.  Thanks to Marcin Krol.

* New version of setup.py that allows better management of NumPy
  dependency.  See PR #133.  Thanks to Aleks Bunin.

Changes from 2.3 to 2.3.1
-------------------------

* Added support for shift-left (<<) and shift-right (>>) binary operators.
  See PR #131. Thanks to fish2000!

* Removed the rpath flag for the GCC linker, because it is probably
  not necessary and it chokes to clang.

Changes from 2.2.2 to 2.3
-------------------------

* Site has been migrated to https://github.com/pydata/numexpr.  All
  new tickets and PR should be directed there.

* [ENH] A `conj()` function for computing the conjugate of complex
  arrays has been added.  Thanks to David Menéndez.  See PR #125.

* [FIX] Fixed a DeprecationWarning derived of using oa_ndim -- 0 and
  op_axes -- NULL when using NpyIter_AdvancedNew() and NumPy 1.8.
  Thanks to Mark Wiebe for advise on how to fix this properly.

Changes from 2.2.1 to 2.2.2
---------------------------

* The `copy_args` argument of `NumExpr` function has been brought
  lack.  This has been mainly necessary for compatibility with
  `PyTables < 3.0`, which I decided to continue to support.  Fixed
  #115.

* The `__nonzero__` method in `ExpressionNode` class has been
  commented out.  This is also for compatibility with `PyTables <
  3.0`.  See #24 for details.

* Fixed the type of some parameters in the C extension so that s390
  architecture compiles.  Fixes #116.  Thank to Antonio Valentino for
  reporting and the patch.

Changes from 2.2 to 2.2.1
-------------------------

* Fixes a secondary effect of "from numpy.testing import `*`", where
  division is imported now too, so only then necessary functions from
  there are imported now.  Thanks to Christoph Gohlke for the patch.

Changes from 2.1 to 2.2
-----------------------

* [LICENSE] Fixed a problem with the license of the
  numexpr/win32/pthread.{c,h} files emulating pthreads on Windows
  platforms.  After persmission from the original authors is granted,
  these files adopt the MIT license and can be redistributed without
  problems.  See issue #109 for details
  (https://code.google.com/p/numexpr/issues/detail?id-110).

* [ENH] Improved the algorithm to decide the initial number of threads
  to be used.  This was necessary because by default, numexpr was
  using a number of threads equal to the detected number of cores, and
  this can be just too much for moder systems where this number can be
  too high (and counterporductive for performance in many cases).
  Now, the 'NUMEXPR_NUM_THREADS' environment variable is honored, and
  in case this is not present, a maximum number of *8* threads are
  setup initially.  The new algorithm is fully described in the Users
  Guide now in the note of 'General routines' section:
  https://code.google.com/p/numexpr/wiki/UsersGuide#General_routines.
  Closes #110.

* [ENH] numexpr.test() returns `TestResult` instead of None now.
  Closes #111.

* [FIX] Modulus with zero with integers no longer crashes the
  interpreter.  It nows puts a zero in the result.  Fixes #107.

* [API CLEAN] Removed `copy_args` argument of `evaluate`.  This should
  only be used by old versions of PyTables (< 3.0).

* [DOC] Documented the `optimization` and `truediv` flags of
  `evaluate` in Users Guide
  (https://code.google.com/p/numexpr/wiki/UsersGuide).

Changes from 2.0.1 to 2.1
---------------------------

* Dropped compatibility with Python < 2.6.

* Improve compatibiity with Python 3:

  - switch from PyString to PyBytes API (requires Python >- 2.6).
  - fixed incompatibilities regarding the int/long API
  - use the Py_TYPE macro
  - use the PyVarObject_HEAD_INIT macro instead of PyObject_HEAD_INIT

* Fixed several issues with different platforms not supporting
  multithreading or subprocess properly (see tickets #75 and #77).

* Now, when trying to use pure Python boolean operators, 'and',
  'or' and 'not', an error is issued suggesting that '&', '|' and
  '~' should be used instead (fixes #24).

Changes from 2.0 to 2.0.1
-------------------------

* Added compatibility with Python 2.5 (2.4 is definitely not supported
  anymore).

* `numexpr.evaluate` is fully documented now, in particular the new
  `out`, `order` and `casting` parameters.

* Reduction operations are fully documented now.

* Negative axis in reductions are not supported (they have never been
  actually), and a `ValueError` will be raised if they are used.


Changes from 1.x series to 2.0
------------------------------

- Added support for the new iterator object in NumPy 1.6 and later.

  This allows for better performance with operations that implies
  broadcast operations, fortran-ordered or non-native byte orderings.
  Performance for other scenarios is preserved (except for very small
  arrays).

- Division in numexpr is consistent now with Python/NumPy.  Fixes #22
  and #58.

- Constants like "2." or "2.0" must be evaluated as float, not
  integer.  Fixes #59.

- `evaluate()` function has received a new parameter `out` for storing
  the result in already allocated arrays.  This is very useful when
  dealing with large arrays, and a allocating new space for keeping
  the result is not acceptable.  Closes #56.

- Maximum number of threads raised from 256 to 4096.  Machines with a
  higher number of cores will still be able to import numexpr, but
  limited to 4096 (which is an absurdly high number already).


Changes from 1.4.1 to 1.4.2
---------------------------

- Multithreaded operation is disabled for small arrays (< 32 KB).
  This allows to remove the overhead of multithreading for such a
  small arrays.  Closes #36.

- Dividing int arrays by zero gives a 0 as result now (and not a
  floating point exception anymore.  This behaviour mimics NumPy.
  Thanks to Gaëtan de Menten for the fix.  Closes #37.

- When compiled with VML support, the number of threads is set to 1
  for VML core, and to the number of cores for the native pthreads
  implementation.  This leads to much better performance.  Closes #39.

- Fixed different issues with reduction operations (`sum`, `prod`).
  The problem is that the threaded code does not work well for
  broadcasting or reduction operations.  Now, the serial code is used
  in those cases.  Closes #41.

- Optimization of "compilation phase" through a better hash.  This can
  lead up to a 25% of improvement when operating with variable
  expressions over small arrays.  Thanks to Gaëtan de Menten for the
  patch.  Closes #43.

- The ``set_num_threads`` now returns the number of previous thread
  setting, as stated in the docstrings.


Changes from 1.4 to 1.4.1
-------------------------

- Mingw32 can also work with pthreads compatibility code for win32.
  Fixes #31.

- Fixed a problem that used to happen when running Numexpr with
  threads in subprocesses.  It seems that threads needs to be
  initialized whenever a subprocess is created.  Fixes #33.

- The GIL (Global Interpreter Lock) is released during computations.
  This should allow for better resource usage for multithreaded apps.
  Fixes #35.


Changes from 1.3.1 to 1.4
-------------------------

- Added support for multi-threading in pure C.  This is to avoid the
  GIL and allows to squeeze the best performance in both multi-core
  machines.

- David Cooke contributed a thorough refactorization of the opcode
  machinery for the virtual machine.  With this, it is really easy to
  add more opcodes.  See:

  http://code.google.com/p/numexpr/issues/detail?id-28

  as an example.

- Added a couple of opcodes to VM: where_bbbb and cast_ib. The first
  allow to get boolean arrays out of the `where` function.  The second
  allows to cast a boolean array into an integer one.  Thanks to
  gdementen for his contribution.

- Fix negation of `int64` numbers. Closes #25.

- Using a `npy_intp` datatype (instead of plain `int`) so as to be
  able to manage arrays larger than 2 GB.


Changes from 1.3 to 1.3.1
-------------------------

- Due to an oversight, ``uint32`` types were not properly supported.
  That has been solved.  Fixes #19.

- Function `abs` for computing the absolute value added.  However, it
  does not strictly follow NumPy conventions.  See ``README.txt`` or
  website docs for more info on this.  Thanks to Pauli Virtanen for
  the patch.  Fixes #20.


Changes from 1.2 to 1.3
-----------------------

- A new type called internally `float` has been implemented so as to
  be able to work natively with single-precision floating points.
  This prevents the silent upcast to `double` types that was taking
  place in previous versions, so allowing both an improved performance
  and an optimal usage of memory for the single-precision
  computations.  However, the casting rules for floating point types
  slightly differs from those of NumPy.  See:

      http://code.google.com/p/numexpr/wiki/Overview

  or the README.txt file for more info on this issue.

- Support for Python 2.6 added.

- When linking with the MKL, added a '-rpath' option to the link step
  so that the paths to MKL libraries are automatically included into
  the runtime library search path of the final package (i.e. the user
  won't need to update its LD_LIBRARY_PATH or LD_RUN_PATH environment
  variables anymore).  Fixes #16.


Changes from 1.1.1 to 1.2
-------------------------

- Support for Intel's VML (Vector Math Library) added, normally
  included in Intel's MKL (Math Kernel Library).  In addition, when
  the VML support is on, several processors can be used in parallel
  (see the new `set_vml_num_threads()` function).  With that, the
  computations of transcendental functions can be accelerated quite a
  few.  For example, typical speed-ups when using one single core for
  contiguous arrays are 3x with peaks of 7.5x (for the pow() function).
  When using 2 cores the speed-ups are around 4x and 14x respectively.
  Closes #9.

- Some new VML-related functions have been added:

  * set_vml_accuracy_mode(mode):  Set the accuracy for VML operations.

  * set_vml_num_threads(nthreads): Suggests a maximum number of
    threads to be used in VML operations.

  * get_vml_version():  Get the VML/MKL library version.

  See the README.txt for more info about them.

- In order to easily allow the detection of the MKL, the setup.py has
  been updated to use the numpy.distutils.  So, if you are already
  used to link NumPy/SciPy with MKL, then you will find that giving
  VML support to numexpr works almost the same.

- A new `print_versions()` function has been made available.  This
  allows to quickly print the versions on which numexpr is based on.
  Very handy for issue reporting purposes.

- The `numexpr.numexpr` compiler function has been renamed to
  `numexpr.NumExpr` in order to avoid name collisions with the name of
  the package (!).  This function is mainly for internal use, so you
  should not need to upgrade your existing numexpr scripts.


Changes from 1.1 to 1.1.1
-------------------------

- The case for multidimensional array operands is properly accelerated
  now.  Added a new benchmark (based on a script provided by Andrew
  Collette, thanks!) for easily testing this case in the future.
  Closes #12.

- Added a fix to avoid the caches in numexpr to grow too much.  The
  dictionary caches are kept now always with less than 256 entries.
  Closes #11.

- The VERSION file is correctly copied now (it was not present for the
  1.1 tar file, I don't know exactly why).  Closes #8.


Changes from 1.0 to 1.1
-----------------------

- Numexpr can work now in threaded environments.  Fixes #2.

- The test suite can be run programmatically by using
  ``numexpr.test()``.

- Support a more complete set of functions for expressions (including
  those that are not supported by MSVC 7.1 compiler, like the inverse
  hyperbolic or log1p and expm1 functions.  The complete list now is:

    * where(bool, number1, number2): number
        Number1 if the bool condition is true, number2 otherwise.
    * {sin,cos,tan}(float|complex): float|complex
        Trigonometric sinus, cosinus or tangent.
    * {arcsin,arccos,arctan}(float|complex): float|complex
        Trigonometric inverse sinus, cosinus or tangent.
    * arctan2(float1, float2): float
        Trigonometric inverse tangent of float1/float2.
    * {sinh,cosh,tanh}(float|complex): float|complex
        Hyperbolic sinus, cosinus or tangent.
    * {arcsinh,arccosh,arctanh}(float|complex): float|complex
        Hyperbolic inverse sinus, cosinus or tangent.
    * {log,log10,log1p}(float|complex): float|complex
        Natural, base-10 and log(1+x) logarithms.
    * {exp,expm1}(float|complex): float|complex
        Exponential and exponential minus one.
    * sqrt(float|complex): float|complex
        Square root.
    * {real,imag}(complex): float
        Real or imaginary part of complex.
    * complex(float, float): complex
        Complex from real and imaginary parts.



.. Local Variables:
.. mode: rst
.. coding: utf-8
.. fill-column: 70
.. End:
