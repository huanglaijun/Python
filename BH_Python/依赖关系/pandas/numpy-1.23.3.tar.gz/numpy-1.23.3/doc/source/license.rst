*************
NumPy license
*************

.. include:: ../../LICENSE.txt
   :literal:
